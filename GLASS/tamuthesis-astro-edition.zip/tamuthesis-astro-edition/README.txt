TAMU LaTeX Template version 1.7.

This version has double spacing around major headings and single spacing around subheadings in the TOC.

Only titlepage.tex and lists.tex hav been changed from version 1.6.
